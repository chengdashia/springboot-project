package cc.rcbb.captcha.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AjCaptchaDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(AjCaptchaDemoApplication.class, args);
    }

}
